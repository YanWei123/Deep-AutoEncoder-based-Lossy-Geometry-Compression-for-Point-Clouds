#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/shape_inference.h"

#include <math.h>

using namespace tensorflow;
REGISTER_OP("Quantization")
	.Input("code: float32")
	.Output("quantized_code: float32")
	.SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
      c->set_output(0, c->input(0));
      return Status::OK();
    });

// REGISTER_OP("QuantizationGrad")
// 	.Input("grad_quantized_code: float32")
// 	.Output("grad_code: float32");
using namespace tensorflow;

class QuantizationOp : public OpKernel{
	public:
		explicit QuantizationOp(OpKernelConstruction* context):OpKernel(context){}
		void Compute(OpKernelContext * context)override{
			// 获取输入 tensor
			const Tensor& input_tensor = context->input(0);
			OP_REQUIRES(context,input_tensor.dims()==2,errors::InvalidArgument("Quantization requires input be of shape (batch,code_length)"));
			auto input = input_tensor.flat<float>();
			int b = input_tensor.shape().dim_size(0);	// batch
			int l = input_tensor.shape().dim_size(1);	// length of code 

			// 创建一个输出 tensor
			Tensor * output_tensor = NULL;
			OP_REQUIRES_OK(context, context->allocate_output(0, TensorShape{b,l}, &output_tensor));
			auto output = output_tensor->flat<float>();

			// round all element
			for(int i=0;i<b;i++){
				for(int j=0;j<l;j++){
					output(i*l+j) = round(input(i*l+j));
				}
			}

		}

};
REGISTER_KERNEL_BUILDER(Name("Quantization").Device(DEVICE_CPU), QuantizationOp);


// class QuantizationGradOp : public OpKernel{
// 	public:
// 		explicit QuantizationGradOp(OpKernelConstruction* context):OpKernel(context){}
// 		void Compute(OpKernelContext * context)override{
// 			// 获取输入 tensor
// 			const Tensor& input_tensor = context->input(0);
// 			auto input = input_tensor.flat<float>();
// 			int b = input_tensor.shape().dim_size(0);	// batch
// 			int l = input_tensor.shape().dim_size(1);	// length of code 

// 			// 创建一个输出 tensor
// 			Tensor * output_tensor = NULL;
// 			OP_REQUIRES_OK(context, context->allocate_output(0, input_tensor.shape(), &output_tensor));
// 			auto output = output_tensor->flat<float>();

// 			// round all element
// 			for(int i=0;i<b;i++){
// 				for(int j=0;j<l;j++){
// 					output(i*l+j) = round(input(i*l+j));
// 				}
// 			}

// 		}

// };