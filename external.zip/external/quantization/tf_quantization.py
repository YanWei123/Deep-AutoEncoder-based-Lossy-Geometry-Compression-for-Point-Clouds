import tensorflow as tf
from tensorflow.python.framework import ops
import os.path as osp


base_dir = osp.dirname(osp.abspath(__file__))

quantization_module = tf.load_op_library(osp.join(base_dir, 'tf_quantization_so.so'))



def quantization(code):

	return quantization_module.quantization(code)

@ops.RegisterShape('Quantization')
def _quantization(op):
	input_shape = op.inputs[0].get_shape().with_rank(2)
	return [tf.TensorShape([op.inputs[0].get_shape().dims[0],op.inputs[0].get_shape().dims[1]])]

@ops.RegisterGradient('Quantization')
def _quantization(op,grad):
	return [grad]


if __name__=='__main__':
	import numpy as np

	with tf.Session('') as sess:
		a = np.random.randn(10,128).astype('float32')
		b = np.random.randn(128,10).astype('float32')

		inp = tf.Variable(a)
		inp2 = tf.constant(b)
		#code = quantization(inp)
		code_before =  tf.matmul(inp,inp2)
		print(code_before)
		code = quantization(code_before)
		print(code)
		loss = code
		train = tf.train.GradientDescentOptimizer(learning_rate=0.05).minimize(loss)
		sess.run(tf.initialize_all_variables())

		show_code_before, code_after, trainloss, _=sess.run([code_before,code,loss,train])
		print('code_before', code_before)
		print('code_after', code)
		print('trainloss', trainloss)

		# for i in range(10):
		# 	trainloss, _ = sess.run([loss,train])
		# 	print(trainloss)	
			


